# The default keymap for the FC660C with Via enabled

Emulates original keymap.

![](https://i.imgur.com/fg89nez.jpg)