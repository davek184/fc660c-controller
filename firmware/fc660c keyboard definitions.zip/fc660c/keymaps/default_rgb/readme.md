# Keymap with Insert LED remapped to RGB control

Emulates original keymap, but replaces insert LED pin with RGB Underglow & respective configuration.
Allows users to add underglow lighting. See [this keebtalk thread](https://www.keebtalk.com/t/adding-rgb-to-fc660c-with-hasu-controller/14484) for more information.

![](https://i.imgur.com/fg89nez.jpg)
