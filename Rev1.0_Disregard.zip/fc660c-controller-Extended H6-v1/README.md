# FC660C Controller with USB-C

![FC660C Controller with USB-C](https://i.imgur.com/KKluQSl.png)

## Features
- Fully compatible with keymaps for Hasu's FC660C controller
- USB-C port (required small case modification)
- ESD protection circuit

## Bill of materials (BOM)
Please have a look at the production files!